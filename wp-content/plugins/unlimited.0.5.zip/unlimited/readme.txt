=== Unlimited ===
Contributors: plugin.builders
Tags: infinite scrolling, ajax pagination, load more, usability, infinite scroll, animation, pagination, ajax, infinite, scroll, scroll to top, top, history, back, forward, custom, auto, opt-out, disable, admin, options
Donate link: http://plugin.builders
Requires at least: 3.0
Tested up to: 4.2.2
Stable tag: 0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Inifinite scrolling plugin. Choose from Load on scroll, Load more button and Ajax Pagination. Includes scroll to top and opt-out button.

== Description ==
Inifinite scrolling plugin. Choose from Load on scroll, Load more button and Ajax Pagination. Visitor can disable auto load (useful to get to footer).
Doesn't break browser Back/Forward buttons. Includes Scroll to Top button (Optional). Works out of the box for default WP themes.

** Translations **

* Spanish - [WebHostingHub](http://www.webhostinghub.com/)


== Screenshots ==
1. Select post and navigation for your custom themes.
1. You can create multiple settings to accomodate different templates.

== Installation ==
Upload Unlimited folder to your wp-content/plugins/ directory.
Activate the plugin through the 'Plugins' menu in WordPress.
Go to Settings > Unlimited to set preferences.
Save, and it's done.

== Changelog ==

= 0.1 =
Initial version.

= 0.3 =
Added screenshots.